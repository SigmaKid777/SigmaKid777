<?php
    if(isset($_POST['login'])){
        include ('login.php');
    }
    if(isset($_POST['signup'])){
        include ('sign-up.php');
    }
?>
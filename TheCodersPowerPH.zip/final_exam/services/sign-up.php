<?php 
	include('signup_login.php') 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign-up</title>
    <link rel="stylesheet" href="../mystyles/signin_loginstyle.css">
    <link rel="stylesheet" href="../mystyles/mynavbar_style.css">
</head>
<body>
    <div class="bg-image1"></div>
    <div class="topnav" id="header">
        <a href="../index.php" id="back"><b>↶</b> Back</a>
    </div>
    <script src="scripts/navbar.js"></script>
    <div class="wrapper signup-margintop">
        <div class="title">
            SIGN-UP
        </div>
        <form method="post" action="sign-up.php" class="form">
            <?php include('errors.php'); ?>
            <div class="inputfield">
                <label>Full Name</label>
                <input type="text" class="input" name="fullname" id="fullname" required>
            </div>
            <div class="inputfield">
                <label>Login Username</label>
                <input type="text" class="input" name="username" id="username" required>
            </div>  
            <div class="inputfield">
                <label>Email</label>
                <input type="email" class="input" name="email" id="email" required>
            </div>  
            <div class="inputfield">
                <label>Login Password</label>
                <input type="password" class="input" name="password_1" id="password_1" required>
            </div>  
            <div class="inputfield">
                <label>Confirm Login Password</label>
                <input type="password" class="input" name="password_2" id="password_2" required>
            </div>  
            <div class="inputfield">
                <input type="submit" value="Register" class="btn" name="reg_user">
            </div>
            <CENTER><h5 class="link">Already a member? <a href="login.php">Login</a></h5></CENTER>
        </form>
    </div>
</body>

<footer>
  <marquee behavior="scroll" direction="left" scrollamount="10">Web Programming Philippines | BSCS - 3A [by TheCodersPower] | North Eastern Mindanao State University | Web Development</marquee> 
</footer>
</html>
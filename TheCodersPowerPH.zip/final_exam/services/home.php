<?php 
include ("conn.php");
include ("signup_login.php");
  if (!isset($_SESSION['username'])) {
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: ../index.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../mystyles/my_homenavbarStyle.css">
    <link rel="stylesheet" href="../mystyles/myhomeStyle.css">
    <link rel="stylesheet" href="../mystyles/scrollTop.css">
</head>
<body>
<button onclick="topFunction()" id="myBtn" title="Go to top">⏏</button>
<div class="header" id="header" >
    <div class="topnav" id="myTopnav">
        <?php  if (isset($_SESSION['username'])) : ?>
			<a href="home.php" class="null"><strong><?php $user_name = $_SESSION['username']; echo " ".$user_name; ?></strong></a>
			<a href="home.php?logout='1'" id="logout">⍈ Logout</a>
        <?php endif ?>
        <div class="dropdown">
            <button class="dropbtn" onclick="myFunction()" id="aboutbtn">About ⏷
            </button>
            <div class="dropdown-content" id="myDropdown">
                <a href="../about_webdev.php">➥ Web-Developer</a>
                <a href="../about_company.php">➥ Company</a>
                <a href="../admin/admin_home.php">➥ Admin Home</a>
            </div>
        </div> 
        <a href="../contact.php">Contact</a>
        <a href="../index.php">⥈ WebProg-PH</a>
        <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="toggleFunction()">&#9776;</a>
    </div>
</div> <script src="../scripts/navbar.js"></script>
<div class="home-container">
    <div class="box-head">
        <div class="profile">
            <div class="gallery">
                <img src="../images/invoker.jpg" alt="profile pic">
            </div>
            <div class="name">
                <?php
                    $username = $_SESSION['username'];
                    $sql = "SELECT id, name FROM tbl_user WHERE username='$username'";
                    $result = mysqli_query($conn, $sql); 
                    if(mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {?>
                        <p class="profile-name">
                            <?php echo $row["name"]; ?>
                        </p>
                        <p class="profile-id">
                            ID Number: (2022-<?php $user_id=$row["id"]; echo $user_id;?>)
                        </p><?php
                        }
                    } ?>
            </div>
        </div>
    </div>
    <div class="box-content">
        <div class="box-1">
            <h2>Global Chat</h2>
            <div class="chatbox">
            <?php
                $sqli = "SELECT * FROM tbl_chat ORDER BY id DESC";
                $result = mysqli_query($conn, $sqli);
          
                if(mysqli_num_rows($result) > 0){
                    while($information = mysqli_fetch_assoc($result)){ ?>
                    <div class="innerchatbox">
                        <div class="nameside">
                            <p><?php echo $information['name'];?> ↴</p>
                        </div>
                        <div class="chatside">
                            <p><?php echo $information['chat'];?></p>   
                            <p class="date"><?php echo "Posted: ".$information['create_at'];?></p>
                        </div> 
                    </div>
                    <?php
                    }
                } else{ 
                       ?><p>Global chat is empty...</p><?php
                }
                ?>
            </div>
            <div class="chatnow">
                <form method="post" class="form" action="chats.php">
                    <input type="hidden" name="user-ID" id="user-ID" value="<?php echo $user_id;?>">
                    <textarea type="text" name="chat-message" class="chat-message" id="chat-message" placeholder="Chat now..." required></textarea>
                    <input type="submit" value="Send" id="send-btn" class="send-btn" name="send-btn">
                </form>
            </div>
        </div>
        <div class="box-2">
            <h2>Events</h2>
            <div class="eventbox">
            <?php
                $mysqli = "SELECT * FROM tbl_event";
                $getresult = mysqli_query($conn, $mysqli);
          
                if(mysqli_num_rows($getresult) > 0){
                    while($information = mysqli_fetch_assoc($getresult)){ ?>
                    <div class="inner-eventbox">
                        <div class="event-title">
                            <h1><?php echo $information['title'];?></h1>
                            <p><?php echo $information['why'];?></p> 
                        </div>
                        <div class="event-content">
                            <p><?php echo "Venue: ".$information['where'];?></p>  
                            <p><?php echo "Schedule: ".$information['date'];?></p>
                        </div> 
                    </div>
                    <?php
                    }
                } else{ 
                       ?><p>No events...</p><?php
                } mysqli_close($conn);
                ?>
            </div>
        </div>
    </div>
    <footer id="footer">
        <marquee behavior="scroll" direction="left" scrollamount="10">Web Programming Philippines | BSCS - 3A [by TheCodersPower] | North Eastern Mindanao State University | Web Development</marquee> 
    </footer>
</div>
</body>
<script src="../scripts/scrollTop.js"></script>
</html>
<?php
    include ('conn.php');

    $id = $_POST['user-ID'];
    $comment = $_POST['chat-message'];
    
    $sql = "SELECT name FROM tbl_user WHERE id = $id";
    $result = mysqli_query($conn, $sql);
    $get_name = mysqli_fetch_assoc($result);
    $name = $get_name['name'];

    $insert_query = "INSERT INTO tbl_chat (name, chat) 
  			        VALUES('$name', '$comment')";
  	
    mysqli_query($conn, $insert_query);
    header("location: home.php");
    
    mysqli_close($conn);
?>
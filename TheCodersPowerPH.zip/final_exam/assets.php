<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Assets</title>
  <link rel="stylesheet" href="mystyles/myhomeStyle.css">
</head>
<body>
  <div class="header">
    <?php include('navbar.php');?>
  </div>
  <div class="home-container">
    <div class="box-head">
        <div class="profile">
            <div class="gallery">
                <img src="../images/invoker.jpg" alt="profile pic">
            </div>
            <div class="name">
                
            </div>
               
        </div>
    </div>
<footer>
  <marquee behavior="scroll" direction="left" scrollamount="10">Web Programming Philippines | BSCS - 3A [by TheCodersPower] | North Eastern Mindanao State University | Web Development</marquee> 
</footer>
  
</body>
</html>

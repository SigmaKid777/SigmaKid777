<?php include ('services/conn.php')?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>WebProg-Educ-PH</title>
  <link rel="stylesheet" href="mystyles/my_aboutwebdev_Style.css">
  <link rel="stylesheet" href="mystyles/scrollTop.css">

</head>
<body>
<button onclick="topFunction()" id="myBtn" title="Go to top">⏏</button>
  <div class="header" id="header">
    <?php include('navbar.php');?>
  </div>
  
  <div class="container">
    <h2>Web-Developers Team</h2>
    <h1>| The Coders Power |</h1>
<?php
  $sqli = "SELECT * FROM tbl_admin";
  $result = mysqli_query($conn, $sqli);
          
  if(mysqli_num_rows($result) > 0){
 
    while($information = mysqli_fetch_assoc($result)){ ?>
  <div class="container2">
  
    <div class="box1">
      <div class="box2">
        <div class="box3">
          <img src="<?php echo $information['image'];?>" alt="profile pic">
        </div>
        <div class="info">
          <table>
            <tr>
              <td>Name:</td>
              <td><?php echo $information['name'];?></td>
            </tr>
            <tr>
              <td>Age:</td>
              <td><?php echo $information['age'];?></td>
            </tr>
            <tr>
              <td>Gender:</td>
              <td><?php echo $information['gender'];?></td>
            </tr>
            <tr>
              <td>Course/Year:</td>
              <td><?php echo $information['course'];?></td>
            </tr>
            <tr>
              <td>Email:</td>
              <td><a href="http://<?php echo $information['email'];?>"><?php echo $information['email'];?></a></td>
            </tr>
            <tr>
              <td>Address:</td>
              <td><?php echo $information['address'];?></td>
            </tr>
             <tr>
              <td>About:</td>
              <td><?php echo $information['about'];?></td>
             </tr> 
          </table>
        </div>
      </div>
    </div>
  </div><?php }}?>
</div>
<footer>
  <marquee behavior="scroll" direction="left" scrollamount="10">Web Programming Philippines | BSCS - 3A [by TheCodersPower] | North Eastern Mindanao State University | Web Development</marquee> 
</footer>
</body>
<script src="scripts/scrollTop.js"></script>
</html>

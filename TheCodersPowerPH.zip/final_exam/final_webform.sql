-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2022 at 03:44 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `final_webform`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(11) NOT NULL,
  `name` varchar(70) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `image` varchar(200) NOT NULL,
  `age` int(100) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `address` varchar(200) NOT NULL,
  `about` varchar(700) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `course` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `name`, `username`, `password`, `email`, `image`, `age`, `gender`, `address`, `about`, `create_at`, `course`) VALUES
(4, 'Christian Joy Ochada', 'christian', 'christian', 'chritianjoy@gmail.com', 'images/profile_Christian.jpg', 22, 'male', 'Purok 5 Brgy. Magosilom, Cantilan, Surigao del Sur, Philippines', 'I love programming!', '2022-12-17 00:09:03', 'BSCS 3A'),
(5, 'Mariel Oso', 'mariel', 'mariel', 'oso.yeyel@gmail.com', 'images/profile_Mariel.jpg', 24, 'male', 'Purok 3 Brgy. Habag, Lanuza, Surigao del Sur, Philippines', 'I love programming! and I hate bugs!', '2022-12-17 00:37:31', 'BSCS 4B'),
(6, 'Allien Derigay', 'allien', 'allien', 'allien@gmail.com]', 'images/profile_icon.png', 20, 'female', 'Poblacion Carmen, Surigao del Sur, Philippines', 'I love programming!', '2022-12-17 00:40:40', 'BSCS 3A'),
(7, 'Judy Ann Alibangabang', 'judyann', 'judyann', 'judyann@gmail.com', 'images/profile_icon.png', 24, 'female', 'Sta. Crus Carmen, Surigao del Sur, Philippines', 'I love programming!', '2022-12-17 00:40:00', 'BSCS 3A'),
(9, 'Daisy Juagpao', 'daisy', 'daisy', 'daisy2022@gmail.com', 'images/profile_icon.png', 21, 'female', 'Agsam, Lanuza, Surigao del Sur, Philippines', 'I love programming! and I hate bugs!', '2022-12-17 00:38:32', 'BSCS 3A'),
(10, 'Shiela Marie', 'shiela', 'shiela', 'shielamarie@gmail.com', 'images/profile_ShielaMarie.jpg', 21, 'female', 'Purok 5 Magosilom, Cantilan, Surigao del Sur, Philippines', 'I love computer programming!', '2022-12-17 00:37:08', 'BSCS 3A');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_chat`
--

CREATE TABLE `tbl_chat` (
  `id` int(11) NOT NULL,
  `name` varchar(70) NOT NULL,
  `chat` varchar(300) NOT NULL,
  `date` varchar(100) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_chat`
--

INSERT INTO `tbl_chat` (`id`, `name`, `chat`, `date`, `create_at`) VALUES
(1, 'Carmela A. Oso', 'Have a nice day', '', '2022-12-16 04:08:04'),
(2, 'Carmela A. Oso', 'A blessed friday.', '', '2022-12-16 04:08:36'),
(3, 'Marites A. Oso', 'sabang kaw', '', '2022-12-16 04:09:51'),
(4, 'Mariel A. Oso', 'Hello World!', '', '2022-12-16 05:39:23'),
(5, 'Mariel A. Oso', 'Wazzup!', '', '2022-12-16 13:31:01'),
(6, 'Mariel A. Oso', 'Goodnight!', '', '2022-12-16 13:31:16'),
(7, 'Mariel A. Oso', 'Good morning!', '', '2022-12-16 22:36:39'),
(8, 'Mariel A. Oso', 'sdfsdf', '', '2022-12-16 22:41:11'),
(9, 'Mariel A. Oso', 'sdfsdf', '', '2022-12-16 22:41:18'),
(10, 'Mariel A. Oso', 'dfsdfsdfdf', '', '2022-12-16 22:41:27'),
(11, 'Mariel A. Oso', 'asdas', '', '2022-12-16 22:42:56'),
(12, 'Mariel A. Oso', 'ffff', '', '2022-12-16 23:22:41'),
(13, 'Mearl A. Oso', 'Wazzup', '', '2022-12-17 04:29:26'),
(14, 'Mearl A. Oso', 'sdkfsjdfkjsd sdf sd sd f sdl  sd s flsd sd sdf  sdskldf slfs sdfs fs d sdkf s d sd lsdkf ldk  sdf klsdf lksdf sd lksd fdf\r\n sd lk\r\n\r\n sdflksd sdf', '', '2022-12-17 04:30:28'),
(15, 'Mearl A. Oso', 'aaaaaaaaaaaa\r\n\r\nbbbbbbbbbbbbbbbb\r\nccccccccccc d', '', '2022-12-17 04:30:46'),
(16, '', 'ehem', '', '2022-12-17 07:24:15'),
(17, '', 'd', '', '2022-12-17 07:30:21'),
(18, 'Mariel Oso', 'ds', '', '2022-12-17 07:32:31'),
(19, 'Admin Mariel Oso', 'sdf', '', '2022-12-17 07:42:11'),
(20, 'Admin Shiela Marie', 'ok', '', '2022-12-17 07:58:33'),
(21, 'Mariel A. Oso', 'aaa', '', '2022-12-17 08:03:05'),
(22, 'Admin ', '', '', '2022-12-17 09:50:08'),
(23, 'Admin Mariel Oso', 'l', '', '2022-12-17 11:05:13'),
(24, 'Admin ', '', '', '2022-12-17 13:30:35'),
(25, 'Admin Mariel Oso', 'sdfsdf', '', '2022-12-17 14:26:05'),
(26, 'Mariel A. Oso', 'asdasd', '', '2022-12-17 14:33:48');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `id` int(11) NOT NULL,
  `name` varchar(70) NOT NULL,
  `email` varchar(100) NOT NULL,
  `comment` varchar(700) DEFAULT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `name`, `email`, `comment`, `create_at`) VALUES
(1, 'Morris A. Oso', 'morris@gmail.com', 'Hi! How are you today?', '2022-12-15 05:24:26');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_event`
--

CREATE TABLE `tbl_event` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `where` varchar(100) NOT NULL,
  `why` varchar(700) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_event`
--

INSERT INTO `tbl_event` (`id`, `title`, `where`, `why`, `date`) VALUES
(20, 'Final Project', 'NEMSU Cantilan, Surigao del Sur, Philippines', 'BSCS Web Development Final Exam', '2022-12-20');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `name` varchar(70) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `username`, `password`, `email`, `create_at`) VALUES
(1000, 'Marites A. Oso', 'marites', '187b1b3750f84b18a05d9ac1e60a528c', 'test@gmail.com', '2022-12-15 06:36:24'),
(1001, 'Mariel A. Oso', 'mariel', '1b8104531493293e377fffac0a56de5f', 'mariel@gmail.com', '2022-12-15 06:45:32'),
(1002, 'Morris A. Oso', 'morris', 'ec726fd938bbf930b86581442b18bec7', 'morris@gmail.com', '2022-12-15 09:17:59'),
(1003, 'Carmela A. Oso', 'Tess', '5caae99531c54bc794f2489f5f2e6f33', 'osomarites75@gmail.com', '2022-12-16 04:07:41'),
(1004, 'Mearl A. Oso', 'mearl', 'c58b0351090532a4cdfa13677aca85bc', 'mearl123@gmail.com', '2022-12-17 04:28:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_chat`
--
ALTER TABLE `tbl_chat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_event`
--
ALTER TABLE `tbl_event`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_chat`
--
ALTER TABLE `tbl_chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_event`
--
ALTER TABLE `tbl_event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1005;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

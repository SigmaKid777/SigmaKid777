<?php
    require '../services/conn.php'; // CONNECTION TO DATABASE (webform)

    $title = $_POST['event-title'];
    $where = $_POST['event-where'];
    $why = $_POST['event-why'];
    $date = $_POST['event-date'];

    // ATTEMPTING OF INSERTING DATA TO THE DATABASE TABLE (tbl_customer) 
    $sql = "INSERT INTO `tbl_event`(`id`, `title`, `where`, `why`, `date`) 
    VALUES ('','$title','$where','$why','$date');";
     
    
    if (mysqli_multi_query($conn, $sql)) { // IF ATTEMPT IS SUCCESSFULL
        header('location: admin_home.php');
    } else { // IF FAILED
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    } 
?>
<?php
include "config.php";
// Check user login or not
if(!isset($_SESSION['uname'])){
    header('Location: admin_index.php');
}

// logout
if(isset($_POST['but_logout'])){
    session_destroy();
    header('Location: admin_index.php');
}
if (isset($_GET['but_logout'])) {
    session_destroy();
    unset($_SESSION['uname']);
    header("location: admin_index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="stylesheet" href="../mystyles/my_homenavbarStyle.css">
    <link rel="stylesheet" href="../mystyles/myhomeStyle.css">
    <link rel="stylesheet" href="adminStyle.css">
    <link rel="stylesheet" href="../mystyles/scrollTop.css">
</head>
<body>
<button onclick="topFunction()" id="myBtn" title="Go to top">⏏</button>
<div class="header" id="header" >
    <div class="topnav" id="myTopnav">
        <?php  if (isset($_SESSION['uname'])) : ?>
			<a href="admin_home.php" class="null"><strong><?php $user_name = $_SESSION['uname']; echo "Admin [".$user_name."]"; ?></strong></a>
        <?php endif ?>
        <div class="dropdown">   
            <button class="dropbtn" onclick="myFunction()" id="aboutbtn">Option ⏷
            </button>
            <div class="dropdown-content" id="myDropdown">
                <form method='post' action="">
                <button class="dropbtn" id="logout" name="but_logout" style="display: flex; width: 100%;"> ⍈ Logout </button>
            </form>
            </div>
        </div>
        <a href="../index.php">⥈ WebProg-PH</a>
        <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="toggleFunction()">&#9776;</a>
    </div>
</div> <script src="../scripts/navbar.js"></script>
<div class="home-container">
    <div class="box-head">
        <div class="profile"><?php
        $username = $_SESSION['uname'];
        $sql = "SELECT id, name, image FROM tbl_admin WHERE username='$username'";
        $result = mysqli_query($con, $sql); 
        if(mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {?>
            <div class="gallery">
                <img src="../<?php echo $row['image'];?>" alt="profile pic">
            </div>
            <div class="name">
                <p class="profile-name">
                    <?php echo $row["name"]; ?>
                </p>
                <p class="profile-id">
                    Admin ID Number: [ 2022 - <?php $admin_id=$row["id"]; echo $admin_id;?> ]
                </p><?php
            }
        } ?>
            </div>
        </div>
    </div>
<!-- ============================================ FIRST CONTENT CONTAINER ========================================================== -->
    <div class="box-content">
        <div class="box-1">
            <h2>Global Chat</h2>
            <div class="chatbox">
            <?php
                $sqli = "SELECT * FROM tbl_chat ORDER BY id DESC";
                $result = mysqli_query($con, $sqli);
          
                if(mysqli_num_rows($result) > 0){
                    while($information = mysqli_fetch_assoc($result)){ ?>
                    <div class="innerchatbox">
                        <div class="nameside">
                            <p><?php echo $information['name'];?> ↴</p>
                        </div>
                        <div class="chatside">
                            <p><?php echo $information['chat'];?></p>   
                            <p class="date"><?php echo "Posted: ".$information['create_at'];?></p>
                        </div> 
                    </div>
                    <?php
                    }
                } else{ 
                       ?><p>Global chat is empty...</p><?php
                }?>
            </div>
            <div class="chatnow">
                <form method="post" class="form" action="../services/admin_chat.php">
                    <input type="hidden" name="user-ID" id="user-ID" value="<?php echo $admin_id;?>">
                    <textarea type="text" name="chat-message" class="chat-message" id="chat-message" placeholder="Chat now..." required></textarea>
                    <input type="submit" value="Send" id="send-btn" class="send-btn" name="send-btn">
                </form>
            </div>
        </div>
        <div class="box-2">
            <h2>Events</h2>
            <div class="eventbox">
            <?php
                $mysqli = "SELECT * FROM tbl_event ORDER BY id DESC";
                $getresult = mysqli_query($con, $mysqli);
          
                if(mysqli_num_rows($getresult) > 0){
                    while($information = mysqli_fetch_assoc($getresult)){ ?>
                    <div class="inner-eventbox">
                        <div class="event-title">
                            <h1><?php echo $information['title'];?></h1>
                            <p><?php echo $information['why'];?></p> 
                        </div>
                        <div class="event-content">
                            <p><?php echo "Venue: ".$information['where'];?></p>  
                            <p><?php echo "Schedule: ".$information['date'];?></p>  
                        </div> 
                    </div>
                    <?php
                    }
                } else{ 
                       ?><p>No events...</p><?php
                }
                ?>
            </div>
        </div>
    </div>

<!-- ============================================ SECOND CONTENT CONTAINER ========================================================== -->

    <div class="box-content">
        <div class="box-3">
            <h2>Customers Question</h2>
            <div class="chatbox">
            <?php
                $sqli = "SELECT * FROM tbl_customer ORDER BY id DESC";
                $result = mysqli_query($con, $sqli);
          
                if(mysqli_num_rows($result) > 0){
                    while($information = mysqli_fetch_assoc($result)){ ?>
                    <div class="innerchatbox">
                        <div class="nameside">
                            <p>From: <?php echo $information['name'];?> ↴</p>
                        </div>
                        <div class="chatside">
                            <p><?php echo $information['comment'];?></p>   
                
                            <p>Reply on his/her Email: <a href="https://<?php echo $information['email'];?>" id="link-email"><?php echo " ".$information['email'];?></a></p> 
                            
                            <p class="date"><?php echo "Sent ".$information['create_at'];?></p>
                        </div> 
                    </div>
                    <?php
                    }
                } else{ 
                       ?><p>Global chat is empty...</p><?php
                }?>
            </div>
            
        </div>
        <div class="box-2">
            <h2>Your Events</h2>
            <div class="eventbox">
            <form action="delete_event.php" method="post">
            <?php
                $mysqli = "SELECT * FROM tbl_event ORDER BY id DESC";
                $getresult = mysqli_query($con, $mysqli);
          
                if(mysqli_num_rows($getresult) > 0){
                    while($information = mysqli_fetch_assoc($getresult)){ ?>
                    <div class="inner-eventbox">
                        <div class="event-title">
                            <h1><?php echo $information['title'];?></h1>
                            <p><?php echo $information['why'];?></p> 
                        </div>
                        <div class="event-content">
                            <p><?php echo "Venue: ".$information['where'];?></p>  
                            <p><?php echo "Schedule: ".$information['date'];?></p>  
                            <a href="delete_event.php?id=<?php echo $information['id']; ?>" class="letsgo-btn" id="delete-btn" name="delete-btn" style="text-decoration:none;">Delete</a>
                        </div> 
                    </div>
                    <?php
                    }
                } else{ 
                       ?><p>No events...</p><?php
                }
                ?>
            </div></form>
        </div>
    </div>




<!-- ========================================= List Of Members Container ========================================================== -->


    <div class="box-content">
        <div class="box-3">
            <h2>Members Information</h2>
            <div class="chatbox">
            <?php
                $sqli = "SELECT * FROM tbl_user";
                $result = mysqli_query($con, $sqli);
          
                if(mysqli_num_rows($result) > 0){
                    while($information = mysqli_fetch_assoc($result)){ ?>
                    <div class="innerchatbox">
                        <div class="nameside">
                            <p>Name: <?php echo $information['name'];?></p>
                        </div>
                        <div class="chatside">
                        <p>ID: <?php echo $information['id'];?></p>
                        <p>Username: <?php echo $information['username'];?></p>
                        <p>Password: [Null (For our members privacy)]</p>
                        <p>Reply on his/her Email: <a href="https://<?php echo $information['email'];?>" id="link-email"><?php echo " ".$information['email'];?></a></p> 
                        <p><?php echo "Account Created: ".$information['create_at'];?></p>
                        </div> 
                    </div>
                    <?php
                    }
                } else{ 
                       ?><p>No members to show...</p><?php
                }?>
            </div>
        </div>




        <div class="box-2">
            <h2>Create New Event</h2>
            <div class="eventbox">
                <form action="insert_event.php" method="post" id="event-form">
                    <div class="inner-eventbox">
                        <div class="inputbox">
                            <p>Title:</p>
                            <input type="text" id="inputbox" name="event-title" placeholder="Title..." required>  
                        </div>    
                        <div class="inputbox">
                            <p>Where:</p>
                            <input type="text" id="inputbox" name="event-where" placeholder="Where..." required>  
                        </div> 
                        <div class="inputbox">
                            <p>Why:</p>
                            <input type="text" id="inputbox" name="event-why" placeholder="Why..." required>  
                        </div> 
                        <div class="inputbox">
                            <p>When:</p> 
                            <input type="date" name="event-date" id="inputbox" required>
                        </div> 

                        <div class="add-event-now" >
                             <input type="submit" value="Add Event Now" id="send-btn" class="send-btn" name="send-btn" style="width: 50%;">
                        </div>
                    </div> 
                </form>
            </div>
        </div>





    </div>

    <footer id="footer">
        <marquee behavior="scroll" direction="left" scrollamount="10">Web Programming Philippines | BSCS - 3A [by TheCodersPower] | North Eastern Mindanao State University | Web Development</marquee> 
    </footer>
</div>
<script src="../scripts/scrollTop.js"></script>
</body>
</html>
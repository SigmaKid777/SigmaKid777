<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="mystyles/mynavbar_style.css">
</head>
<body>
    <div class="topnav" id="myTopnav">
        <a href="services/home.php" class="active">⟰ Home</a>
        <div class="dropdown">
            <button class="dropbtn" id="dropbtn" onclick="myFunction()">About ⏷
            </button>
            <div class="dropdown-content" id="myDropdown">
                <a href="about_webdev.php">➥ Web-Developer</a>
                <a href="about_company.php">➥ Company</a>
                <a href="admin/admin_home.php">➥ Admin Home</a>
            </div>
        </div> 
        <a href="contact.php">Contact</a>
        <a href="index.php">⥈ TCP-Ph</a>
        <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="toggleFunction()">&#9776;</a>
    </div>
  <script src="scripts/navbar.js"></script>
</body>
</html>
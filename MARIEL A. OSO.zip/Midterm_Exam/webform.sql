-- -------WEBFORM.SQL ------- --

-- Create Database
CREATE DATABASE webform;

-- Create Table for User
CREATE TABLE webform.tbl_user (
  id INT NOT NULL PRIMARY KEY AUTO_INCREMENT=1000,
  `name` varchar(70) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Create Table for Customer
CREATE TABLE webform.tbl_customer (
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT=1000,
    `name` varchar(70) NOT NULL,
    `email` varchar(100) NOT NULL,
    `website` varchar(200) NULL,
    `comment` varchar(700) NULL,
    `gender` varchar(10) NOT NULL,
    `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=latin1;

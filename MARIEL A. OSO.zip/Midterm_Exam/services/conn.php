<?php
    $HOST = "localhost";
    $USERNAME = "root";
    $PASSWORD = "";
    $DB_NAME = "webform";

    $conn = mysqli_connect($HOST, $USERNAME, $PASSWORD, $DB_NAME);
 
    if(!$conn){
        
        die("ERROR: Could Not Connect. " . mysqli_connect_error());
    }
?>
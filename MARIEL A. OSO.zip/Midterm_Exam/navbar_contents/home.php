<?php 
include ("../services/signin_login.php");
  if (!isset($_SESSION['username'])) {
  	header('location: ../login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: ../index.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MIDTERM EXAM</title>
    <link rel="stylesheet" href="../mystyles/index_styles.css">
</head>
<body>
    <div class="header">
        <h1>NORTH EASTERN MINDANAO STATE UNIVERSITY</h1>
        <div class="navbar">
			<?php  if (isset($_SESSION['username'])) : ?>
            <a href="home.php?logout='1'" class="logout">Logout</a>
			<a class="null"><strong><?php echo " ".$_SESSION['username']; ?></strong></a>
			<?php endif ?>
            <a href="../index.php" class="index">NEMSU Cantilan</a>
            <a href="journal.php" class="right">Journals</a>
            <a href="laboratories.php" class="right">Laboratories</a>
            <a href="about.php" class="right">About</a>
            <a href="home.php" class="active right">Home</a>
        </div>
    </div>
	<div class="row">
        <div class="innerbox">
            <p class="welcome">WELCOME<br>
			    <?php
                    include ("../services/conn.php");
                    $username = $_SESSION['username'];
                    $sql = "SELECT id, name FROM tbl_user WHERE username='$username'";
                    $result = mysqli_query($conn, $sql); 
                    if(mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {?>
                        <p class="name">
                            <?php echo $row["name"]; ?>
                        </p>
                        <p class="id">
                            ID Number: (2022-<?php echo  $row["id"];?>)
                        </p><?php
                        }
                    }
                ?>
            </p>   
            <p class="dcs"> to the</p>
        </div>
        <div style="width: 100%;">
            <img src="../images/dcs_logo.jpg" alt="dcs_logo" style="width: 100%;">
        </div>
    </div>
    <footer><h2>NUMSU - DCS | BSCS - Mariel A. Oso</h2></footer>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MIDTERM EXAM</title>
    <link rel="stylesheet" href="../mystyles/index_styles.css">
    <link rel="stylesheet" href="../mystyles/about_styles.css">
</head>
<body>
    <div class="header">
        <h1>NORTH EASTERN MINDANAO STATE UNIVERSITY</h1>
        <div class="navbar">
            <a href="../index.php" class="index">NEMSU Cantilan</a>
            <a href="journal.php" class="right">Journals</a>
            <a href="laboratories.php" class="right">Laboratories</a>
            <a href="about.php" class="right">About</a>
            <a href="home.php" class="active right">Home</a>
        </div>
    </div>
    
    <div class="row"> 
        <div class="top">
            <div class="logo"></div>
        </div>
        <div class="nemsu">
            <p class="texts">North Eastern Mindanao State University<br>
            formerly: Surigao del Sur State University</p>
        </div>
        <div class="mission">
            <div class="innerbox">
                <p class="titles">MISSION</p>
                <p class="texts">A transformative leading University in Asia and the Pacific.</p>
            </div>
        </div>
        <div class="vision">
            <div class="innerbox">
                <p class="titles">VISION</p>
                <p class="texts">NEMSU shall provide competency-based higher education training driven 
                    by relevant and responsive instruction, research, extension and sustainable resource 
                    management.
                </p>
            </div>
        </div>
    </div>
    <footer><h2>NUMSU - DCS | BSCS - Mariel A. Oso</h2></footer>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MIDTERM EXAM</title>
    <link rel="stylesheet" href="../mystyles/index_styles.css">
</head>
<body>
    <div class="header">
        <h1>NORTH EASTERN MINDANAO STATE UNIVERSITY</h1>
        <div class="navbar">
            <a href="../index.php" class="index">NEMSU Cantilan</a>
            <a href="journal.php" class="right">Journals</a>
            <a href="laboratories.php" class="right">Laboratories</a>
            <a href="about.php" class="right">About</a>
            <a href="home.php" class="active right">Home</a>
        </div>
    </div>
    <footer><h2>NUMSU - DCS | BSCS - Mariel A. Oso</h2></footer>
</body>
</html>
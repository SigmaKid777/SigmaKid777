<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MIDTERM EXAM</title>
    <link rel="stylesheet" href="mystyles/index_styles.css">
    <link rel="stylesheet" href="mystyles/validationform_style.css">
</head>
<body>
    <div class="header">
        <h1>NORTH EASTERN MINDANAO STATE UNIVERSITY</h1>
        <div class="navbar">
            <a href="index.php" class="null">NEMSU Cantilan</a>
            <a href="navbar_contents/journal.php" class="right">Journals</a>
            <a href="navbar_contents/laboratories.php" class="right">Laboratories</a>
            <a href="navbar_contents/about.php" class="right">About</a>
            <a href="navbar_contents/home.php" class="active right">Home</a>
        </div>
    </div>
    <div class="row">
        <div class="side">
            <div class="innerbox">
                <p class="welcome">WELCOME!</p>
                <p class="dcs">DEPARTMENT OF</p>
                <p class="dcs">COMPUTER STUDIES</p>
                <span>“Technology is just a tool. In terms of getting the kids working together and motivating</span><br/>
                <span>  them, the teacher is most important.” - Bill Gates</span>       
            </div>
        </div>
        <div class="main">
            <div class="innerbox">
                <div class="wrapper">
                    <div class="title">
                        PHP Validation Form
                    </div>
                    <form method="post" action="services/insert-customer.php" class="form">
                        <div class="inputfield">
                            <label>Name</label>
                            <input type="text" class="input" name="name" id="name" required>
                        </div>  
                        <div class="inputfield">
                            <label>E-mail</label>
                            <input type="text" class="input" name="email" id="email" required>
                        </div>  
                        <div class="inputfield">
                            <label>Website</label>
                            <input type="text" class="input" name="website" id="website">
                        </div>  
                        <div class="inputfield">
                            <label>Comment</label>
                            <textarea style="resize: none; height: 100px;" type="text" class="input" name="comment" id="comment"></textarea>
                        </div> 
                        <div class="inputfield">
                            <label>Gender</label>
                            <div class="radio">
                                <input type="radio" name="gender" id="gender" value="female" required>
                                  Female
                                <input type="radio" name="gender" id="gender" value="male" required>
                                  Male
                                <input type="radio" name="gender" id="gender" value="other" required>
                                  Other
                            </div>
                        </div> 
                        <div class="inputfield">
                            <input type="submit" value="Register" class="btn">
                        </div>
                        <CENTER><h5 class="link">Connect with us. <a href="login.php">Login</a> or <a href="sign-up.php">Sign-up</a></h5></CENTER>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <footer><h2>NUMSU - DCS | BSCS - Mariel A. Oso</h2></footer>
</body>
</html>
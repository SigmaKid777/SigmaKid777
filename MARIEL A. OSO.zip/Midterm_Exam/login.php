<?php 
	include('services/signin_login.php') 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MIDTERM EXAM</title>
    <link rel="stylesheet" href="mystyles/signin_login.css">
</head>
<body>
    <div class="header">
        <h1>NORTH EASTERN MINDANAO STATE UNIVERSITY</h1>
        <div class="navbar">
            <a href="index.php" class="index">Back</a>
        </div>
    </div>
    <div class="wrapper">
        <div class="title">
            LOGIN FORM
        </div>
        <form method="post" class="form" action="login.php">
            <?php include('user/errors.php'); ?>
            <div class="inputfield">
                <label>Username</label>
                <input type="text" class="input" name="username" id="username" required>
            </div>  
            <div class="inputfield">
                <label>Password</label>
                <input type="password" class="input" name="password" id="password" required>
            </div>  
            <div class="inputfield">
                <input type="submit" value="Login" class="btn" name="login_user">
            </div>
            <CENTER><h5 class="link">Not yet a member? <a href="sign-up.php">Sign-up</a></h5></CENTER>
        </form>
    </div>
</body>
</html>
<?php 
	include('services/signin_login.php') 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MIDTERM EXAM</title>
    <link rel="stylesheet" href="mystyles/signin_login.css">
</head>
<body>
    <div class="header">
        <h1>NORTH EASTERN MINDANAO STATE UNIVERSITY</h1>
        <div class="navbar">
            <a href="index.php" class="index">Back</a>
        </div>
    </div>
    <div class="wrapper">
        <div class="title">
            REGISTRATION FORM
        </div>
        <form method="post" action="sign-up.php" class="form">
            <?php include('user/errors.php'); ?>
            <div class="inputfield">
                <label>Full Name</label>
                <input type="text" class="input" name="fullname" id="fullname" required>
            </div>
            <div class="inputfield">
                <label>Login Username</label>
                <input type="text" class="input" name="username" id="username" required>
            </div>  
            <div class="inputfield">
                <label>Email</label>
                <input type="email" class="input" name="email" id="email" required>
            </div>  
            <div class="inputfield">
                <label>Login Password</label>
                <input type="password" class="input" name="password_1" id="password_1" required>
            </div>  
            <div class="inputfield">
                <label>Confirm Login Password</label>
                <input type="password" class="input" name="password_2" id="password_2" required>
            </div>  
            <div class="inputfield">
                <input type="submit" value="Register" class="btn" name="reg_user">
            </div>
            <CENTER><h5 class="link">Already a member? <a href="login.php">Login</a></h5></CENTER>
        </form>
    </div>
</body>
</html>
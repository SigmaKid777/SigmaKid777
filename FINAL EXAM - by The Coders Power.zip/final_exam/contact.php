<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact</title>
  <link rel="stylesheet" href="mystyles/my_contactstyle.css">
</head>
<body>
  <div class="header">
    <?php include('navbar.php');?>
  </div>
  <div class="contact-container">
    <div class="box-head">
        <div class="title">
            <div class="gallery">
                <img src="images/contact_us.jpg" alt="profile pic">
            </div>  <h2>Contact or visit us on...</h2>
            <div class="contact-link">
              
                <a href="https://www.facebook.com/" class="link facebook">Facebook</a>
                <a href="https://www.twitter.com/" class="link twitter">Twitter</a>
                <a href="https://www.gmail.com/" class="link gmail">Gmail</a>
            </div>        
        </div>
    </div>
<footer>
  <marquee behavior="scroll" direction="left" scrollamount="10">Web Programming Philippines | BSCS - 3A [by TheCodersPower] | North Eastern Mindanao State University | Web Development</marquee> 
</footer>

</body>
</html>

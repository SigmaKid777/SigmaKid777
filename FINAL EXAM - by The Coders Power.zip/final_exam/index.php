<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>WebProg-Educ-PH</title>
  <link rel="stylesheet" href="mystyles/my_indexstyle.css">
</head>
<body>
  <div class="header" id="header">
    <?php include('navbar.php');?>
  </div>
  <div class="bg-image"></div>
  <div class="bg-text">
    <h2>Welcome to</h2>
    <h1 style="font-size:50px">WebProg Philippines</h1>
    <h3>Our company lauched an event! </h3><h3>Where everyone could meet us and learn!</h3>
    <h5>(Join us and find new friends by Signing-up or just Login if you're already a member)</h5>
    <form method="post" action="services/serve_index.php">
      <button type="submit" name="login" id="login" class="login">Login</button>
      <span>or</span>
      <button type="submit" name="signup" id="signup" class="signup">Sign-up</button>
    </form>
  </div>
  <div class="break">
    <div class="line"></div>
  </div>
  <div class="container">
    <div class="box1">
      <h1>Please ask any question</h1>
      <form method="post" class="validation-form" action="services/customer.php">
        <div class="inputbox">
          <label for="name">Name</label>
          <input type="text" name="name" id="name" placeholder="Name..." required></input>
        </div>
        <div class="inputbox">
          <label for="email">Email</label>
          <input type="email" name="email" id="email" placeholder="Email..." required></input>
        </div> 
        <div class="inputbox">
            <textarea name="comment" id="comment" cols="30" rows="10" placeholder="Your question here..." required></textarea>
        </div>      
        <input type="submit" name="submit-btn" id="submit-btn" class="submit" value="Submit"></input>
      </form>
    </div>
    <div class="box2">
      <div class="mySlides slide1">
        <h1>Come And Join Us</h1>        
      </div>
      <div class="mySlides slide2">
        <h1>Where We Share</h1>        
      </div>
      <div class="mySlides slide3">
        <h1>And You'll Learn</h1>        
      </div>
      <div class="mySlides slide4">
        <h1>Happy Programming!</h1>        
      </div>
      <script src="scripts/index_slide.js"></script>
    </div>
  </div>
</div>
<footer>
  <marquee behavior="scroll" direction="left" scrollamount="10">Web Programming Philippines | BSCS - 3A [by TheCodersPower] | North Eastern Mindanao State University | Web Development</marquee> 
</footer>
</body>
</html>

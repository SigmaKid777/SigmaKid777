<?php
    require '../services/conn.php'; // CONNECTION TO DATABASE (webform)

	$id=$_GET['id'];
	mysqli_query($conn,"DELETE from `tbl_event` WHERE id='$id'");
	header('location:admin_home.php');
?>
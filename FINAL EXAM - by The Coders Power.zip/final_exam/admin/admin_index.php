<?php
include "config.php";
if(isset($_POST['but_submit'])){
    $uname = mysqli_real_escape_string($con,$_POST['txt_uname']);
    $password = mysqli_real_escape_string($con,$_POST['txt_pwd']);
    if ($uname != "" && $password != ""){
        $sql_query = "select count(*) as cntUser from tbl_admin where username='".$uname."' and password='".$password."'";
        $result = mysqli_query($con,$sql_query);
        $row = mysqli_fetch_array($result);
        $count = $row['cntUser'];
        if($count > 0){
            $_SESSION['uname'] = $uname;
            header('Location: admin_home.php');
        }else{
            echo "Invalid username and password";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login as admin</title>
    <link rel="stylesheet" href="adminStyle.css">
    <link rel="stylesheet" href="../mystyles/signin_loginstyle.css">
    <link rel="stylesheet" href="../mystyles/mynavbar_style.css">
</head>
<body>
    <div class="bg-image1"></div>
    <div class="topnav" id="header">
        <a href="../about_company.php" id="back"><b>↶</b> Back</a>
    </div>
    <script src="scripts/navbar.js"></script>
    <div class="wrapper">
        <div class="title">
            LOGIN AS ADMIN
        </div>
        <form method="post" class="form" action="">
            <div class="inputfield">
                <label>Username</label>
                <input type="text" class="input" id="txt_uname" name="txt_uname" placeholder="Username" required>
            </div>  
            <div class="inputfield">
                <label>Password</label>
                <input type="password" class="input" id="txt_uname" name="txt_pwd" placeholder="Password" required>
            </div>  
            <div class="inputfield">
                <input type="submit" value="Login" class="btn" name="but_submit" id="but_submit">
            </div>
        </form>
    </div>

</body> 
<footer>
  <marquee behavior="scroll" direction="left" scrollamount="10">Web Programming Philippines | BSCS - 3A [by TheCodersPower] | North Eastern Mindanao State University | Web Development</marquee> 
</footer>
</body>
</html>
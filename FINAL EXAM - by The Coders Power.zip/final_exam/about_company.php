<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>TCP-Ph</title>
  <link rel="stylesheet" href="mystyles/my_indexstyle.css">
</head>
<body>
  <div class="header" id="header">
    <?php include('navbar.php');?>
  </div>
  <div class="bg-image"></div>
  <div id="ourself">
    <h1>OURSELF</h1>
    <h1 style="font-size:50px">TheCodersPower Philippines</h1>
    <h3 style="line-height: 1.7;">We are an excellent team of programmers, designers, developers, and analysts united on the same page this digital age to provide state of the art complete IT Web Developers solutions.We exist in NEMSU, Cantilan, Surigao del Sur, Philippines.</h3>

    <form method="post" action="admin/admin_index.php">
      <button type="submit" name="login_admin" id="login_admin" class="login_admin">Login as admin</button>
    </form>
  </div>
</div>
<footer>
  <marquee behavior="scroll" direction="left" scrollamount="10">Web Programming Philippines | BSCS - 3A [by TheCodersPower] | North Eastern Mindanao State University | Web Development</marquee> 
</footer>
</body>
</html>

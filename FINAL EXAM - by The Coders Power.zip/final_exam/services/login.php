<?php 
	include('signup_login.php') 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="../mystyles/signin_loginstyle.css">
    <link rel="stylesheet" href="../mystyles/mynavbar_style.css">
</head>
<body>
    <div class="bg-image1"></div>
    <div class="topnav" id="header">
        <a href="../index.php" id="back"><b>↶</b> Back</a>
    </div>
    <script src="scripts/navbar.js"></script>
    <div class="wrapper">
        <div class="title">
            LOGIN
        </div>
        <form method="post" class="form" action="login.php">
        <span class="error">
            <?php include('errors.php'); ?>
        </span>
            <div class="inputfield">
                <label>Username</label>
                <input type="text" class="input" name="username" id="username" required>
            </div>  
            <div class="inputfield">
                <label>Password</label>
                <input type="password" class="input" name="password" id="password" required>
            </div>  
            <div class="inputfield">
                <input type="submit" value="Login" class="btn" name="login_user">
            </div>
            <CENTER><h5 class="link">Not yet a member? <a href="sign-up.php">Sign-up</a></h5></CENTER>
        </form>
    </div>
</body> 
<footer>
  <marquee behavior="scroll" direction="left" scrollamount="10">Web Programming Philippines | BSCS - 3A [by TheCodersPower] | North Eastern Mindanao State University | Web Development</marquee> 
</footer>
</html>
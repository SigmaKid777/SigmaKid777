<?php
    require ('conn.php'); // CONNECTION TO DATABASE (webform)

    $name = $_POST['name'];
    $email = $_POST['email'];
    $comment = $_POST['comment'];

    // ATTEMPTING OF INSERTING DATA TO THE DATABASE TABLE (tbl_customer) 
    $sql = "INSERT INTO tbl_customer (name, email, comment)
            VALUES ('$name', '$email', '$comment');";
     
    
    if (mysqli_multi_query($conn, $sql)) { // IF ATTEMPT IS SUCCESSFULL
        header('location: ../index.php');
    } else { // IF FAILED
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    } 
    mysqli_close($conn);
?>
<?php
    include ('conn.php');

    $id = $_POST['user-ID'];
    $comment = $_POST['chat-message'];
    
    $sql = "SELECT name FROM tbl_admin WHERE id = $id";
    $result = mysqli_query($conn, $sql);
    $get_name = mysqli_fetch_assoc($result);
    $name = ("Admin ".$get_name['name']);

    $insert_query = "INSERT INTO tbl_chat (name, chat) 
  			        VALUES('$name', '$comment')";
  	
    mysqli_query($conn, $insert_query);
    header("location: ../admin/admin_home.php");
    
    mysqli_close($conn);
?>
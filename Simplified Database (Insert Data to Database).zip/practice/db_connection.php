<?php
    $conn = mysqli_connect('localhost','root','','practice');
    
    if(!$conn){
        die("Unable to Connect");
    }
?>
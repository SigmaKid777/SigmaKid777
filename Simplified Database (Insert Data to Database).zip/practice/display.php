<?php require 'db_connection.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display</title>
</head>
<body>
    <?php
        $sqli = "SELECT * FROM information";
        $result = mysqli_query($conn, $sqli);
    ?>
    <table class="table">
        <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Phone</th>
            <th>View</th>
            <th>Update</th>
            <th>Delete</th>
        </tr>
    <?php
        if(mysqli_num_rows($result) > 0){
            while($information = mysqli_fetch_assoc($result)){?>
                <tr>
                    <td><?php echo $information['fname'];?></td>
                    <td><?php echo $information['lname'];?></td>
                    <td><?php echo $information['phone'];?></td>
                </tr>
            <?php
            }
        } else{
            echo "0 result";
        }
        mysqli_close($conn);
    ?>
    </table>

    <a href="index.php">Go back to Home</a>
    
</body>
</html>
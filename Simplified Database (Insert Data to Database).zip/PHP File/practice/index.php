<?php require 'db_connection.php';?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="">
    <title>Home</title>
</head>
<body>
    <div class="division-form">
        <form action="" method="post">
            First Name <br>
            <input type="text" name="firstname" placeholder="First Name"><br><br>
            Last Name <br>
            <input type="text" name="lastname" placeholder="Last Name"><br><br>
            Phone <br>
            <input type="text" name="phone" placeholder="Phone"><br><br>
            <input type="submit" value="Save Data">
        </form>
    </div>

    <?php
        if(isset($_POST['firstname'])){
            $firstname = $_POST['firstname'];
            $lastname = $_POST['lastname'];
            $phone = $_POST['phone'];

            $sql = "INSERT INTO `information`(`fname`, `lname`, `phone`) 
                        VALUES ('$firstname','$lastname','$phone')";
            
            if(mysqli_query($conn,$sql)){
                echo "<script>alert('Record created successfully');</script>";
            } else{
                echo "<script>alert('Error: Unsuccessful');</script>";
            }
        }
        mysqli_close($conn);
    ?>

    <a href="display.php">See the Data from the Database</a>

</body>
</html>
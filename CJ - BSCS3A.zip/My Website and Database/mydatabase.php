<?php
$link = mysqli_connect("localhost", "root", "");
 
// Checking connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Create database
$sql = "CREATE DATABASE registration";
if(mysqli_query($link, $sql)){
    echo "Database created successfully";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Closing connection
mysqli_close($link);
?>
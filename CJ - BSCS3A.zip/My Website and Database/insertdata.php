<?php
	// Assigning 'names' from the form to php $variables
	$name = $_POST['name'];
	$email = $_POST['email'];
	$website = $_POST['website'];
	$comment = $_POST['comment'];
	$gender = $_POST['gender'];
	// If required inputs from the form are/is NOT EMPTY
	if (!empty($name) || !empty($email) || !empty($gender)){
		$host = "localhost";
		$username = "root";
		$password = "";
		$dbname = "registration";
		// Checking database connection
		$conn = new mysqli($host, $username, $password, $dbname);
		if (mysqli_connect_error()){
			die('Connection Error('. mysqli_connect_errno().')'. mysqli_connect_error());
		}else{
			// Selecting one 'email' only from the database table 'tbl_member'
			$SELECT = "SELECT email From registered_users Where email = ? Limit 1";

			// Inserting data to database table 'tbl_member'
			$INSERT = "INSERT Into registered_users (name, email, website, comment, gender) values(?, ?, ?, ?, ?)";
			// Variable $stmt as Statement and $rnum as Number of Rows
			$stmt = $conn->prepare($SELECT);
			$stmt->bind_param("s", $email);
			$stmt->execute();
			$stmt->store_result();
			$rnum = $stmt->num_rows();
			// If the Statement that Number of Rows is TRUE: Then proceed to inserting the data to database table 'tbl_member
			if ($rnum==0){
				$stmt->close();

				$stmt = $conn->prepare($INSERT);
				$stmt->bind_param("sssss", $name, $email, $website, $comment, $gender);
				$stmt->execute();
				echo "New record inserted successfully";
			}else { // If the Statement that Number of Rows is FALSE: 
				echo "Someone already register using this email";
			}
		}
	}else{ // If the required inputs from the form are/is EMPTY
		echo "Field required";
		die();
	}
?>
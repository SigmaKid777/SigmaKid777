<?php
$link = mysqli_connect("localhost", "root", "", "registration");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
// Create table
$sql = "CREATE TABLE `registered_users` (
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `name` varchar(70) NOT NULL,
    `email` varchar(200) NOT NULL UNIQUE,
    `website` varchar(200) NULL,
    `comment` varchar(900) NULL,
    `gender` varchar(10) NOT NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=latin1;";

if(mysqli_query($link, $sql)){
    echo "Table created successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
// Close connection
mysqli_close($link);
?>